package com.kh.ch09_interface;

public interface GrowingPlant {
	
	/*public abstract*/ void sprinkleWater();
	void baskSun();
}
